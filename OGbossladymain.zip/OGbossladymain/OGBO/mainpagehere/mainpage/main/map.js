const API_URL = 'https://api.v2.emissions-api.org/api/v2/carbonmonoxide/geo.json' +
    '?country=US&begin=2019-05-01&end=2019-05-04';

new deck.DeckGL({
    container: 'container',
    mapboxApiAccessToken: '<your mapbox token>',
    mapStyle: "mapbox://styles/mapbox/dark-v9",
    longitude: -97,
    latitude: 40,
    zoom: 3,
    pitch: 60,
    layers: [
        new deck.HexagonLayer({
            extruded: true,
            radius: 30000,
            data: API_URL,
            dataTransform: d => d.features,
            elevationScale: 300,
            getColorValue: points => points.reduce((sum, point) => sum + point.properties.value, 0) / points.length,
            getElevationValue: points => points.reduce((sum, point) => sum + point.properties.value, 0) / points.length,
            getPosition: d => d.geometry.coordinates,
        }),
    ]
});